import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    // Proxy /api calls to Anthropic during local dev
    proxy: {
      "/api": {
        target: "https://api.anthropic.com",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ""),
        configure: (proxy) => {
          proxy.on("proxyReq", (proxyReq) => {
            proxyReq.setHeader("x-api-key", process.env.ANTHROPIC_API_KEY || "");
            proxyReq.setHeader("anthropic-version", "2023-06-01");
          });
        },
      },
    },
  },
});
